/*****************************************************************************
* Copyright 2011 Nexteer Automotive, All Rights Reserved.
* Nexteer Confidential
*
* Module File Name  : Compiler_Cfg.h
* Module Description: This file contains a stub header for UTP and QAC 
*                     projects
* Product           : Gen II Plus EA3.0
* Author            : Lucas Wendling
*****************************************************************************/
/*---------------------------------------------------------------------------
* Version Control:
* Date Created:      Fri May  9 16:48:22 2003
* %version:          1 %
* %derived_by:       qz0qz9 %
* %date_modified:    Fri Dec  2 19:05:40 2011 %
*---------------------------------------------------------------------------*/
#ifndef COMPILER_CFG_H
#define COMPILER_CFG_H



#endif  /* COMPILER_CFG_H */
